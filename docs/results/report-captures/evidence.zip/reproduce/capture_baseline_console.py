from pathlib import Path
import os,sys,subprocess,tempfile,tarfile,io,json,difflib
ROOT=Path(__file__).resolve().parents[2];REPO=ROOT/'xv6-plus'
OUT=ROOT/'report-evidence/report-baseline-console'
assert not OUT.exists()
os.environ['XV6_RESULTS']=str(OUT);sys.path.insert(0,str(REPO/'tools'))
from validation.harness import Guest
original_popen=subprocess.Popen
def readable(args,*a,**k):
    if isinstance(args,list):args=[x.replace('vc,id=vc0,cols=90,rows=30','vc,id=vc0,cols=64,rows=46') for x in args]
    return original_popen(args,*a,**k)
subprocess.Popen=readable
g=None
try:
    with tempfile.TemporaryDirectory(prefix='xv6-baseline-capture-') as temp:
        data=subprocess.check_output(['git','archive','v0.0'],cwd=REPO)
        with tarfile.open(fileobj=io.BytesIO(data)) as a:a.extractall(temp,filter='data')
        p=Path(temp)/'kernel/console.c';before=p.read_text()
        assert before.count('    uartputc_sync(c);')==1
        assert before.count('    uartputc(c);')==1
        after=before.replace('    uartputc_sync(c);',"    if(c == '\\n') uartputc_sync('\\r');\n    uartputc_sync(c);")
        after=after.replace('    uartputc(c);',"    if(c == '\\n') uartputc('\\r');\n    uartputc(c);")
        p.write_text(after)
        g=Guest('eager-v0.0',source=Path(temp),cpus=1,ram=128,policy=1)
        g.cmd('baseline','sbrk(200MB) failed');assert g.capture('reservation-failure')
        g.close();g.cleanup();g=None
        (OUT/'console-format-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='v0.0/kernel/console.c',tofile='capture/kernel/console.c')))
    (OUT/'complete.json').write_text(json.dumps({'complete':True,'tag':'v0.0','tag_commit':subprocess.check_output(['git','rev-parse','v0.0'],cwd=REPO,text=True).strip(),
      'temporary_change':'CR before LF in serial output only; allocator and baseline.c are byte-identical to tag',
      'source_working_tree_changed':False},indent=2))
finally:
    if g:g.close();g.cleanup()
