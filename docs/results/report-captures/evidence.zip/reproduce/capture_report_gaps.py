"""Run unchanged project commands and preserve native, readable console captures."""
from pathlib import Path
import os,sys,subprocess,json,hashlib

ROOT=Path(__file__).resolve().parents[2]
REPO=ROOT/'xv6-plus'
OUT=ROOT/'report-evidence/report-capture-refresh'
assert not OUT.exists(), 'Use a new evidence directory; never overwrite old runs.'
os.environ['XV6_RESULTS']=str(OUT)
sys.path.insert(0,str(REPO/'tools'))
from validation.harness import Guest

# The unchanged harness uses an actual QEMU virtual console. Select a narrower
# viewport for print readability; the serial stream remains complete and exact.
original_popen=subprocess.Popen
def readable_popen(args,*rest,**kwargs):
    if isinstance(args,list):
        args=[a.replace('vc,id=vc0,cols=90,rows=30',
                        'vc,id=vc0,cols=64,rows=46') for a in args]
    return original_popen(args,*rest,**kwargs)
subprocess.Popen=readable_popen

g=None
try:
    g=Guest('control-and-parallel',source=REPO,cpus=3,ram=128,policy=1)
    for command,marker,name in [
        ('trace 32 cat README','syscall read','trace-read'),
        ('trace 128 echo hi','syscall exec -> 2','trace-exec'),
        ('sigtest','sigtest: ALL OK','signals'),
        ('dbgmini','final reason 3','debugger'),
        ('dbglife','dbglife: OK','debugger-lifetime'),
        ('speedup 1','checksum=1914453504','scaling-one'),
        ('speedup 3','checksum=1914453504','scaling-three')]:
        g.cmd(command,marker)
        assert g.capture(name)
    g.close();g.cleanup();g=None
    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    (OUT/'complete.json').write_text(json.dumps({'complete':True,'source_revision':revision,
      'purpose':'Missing report capture coverage on unchanged project code',
      'viewport':{'columns':64,'rows':46},
      'configuration':{'cpus':3,'managed_ram_mib':128,'policy':1},
      'timing_use':'Illustrative capture only; existing five-trial tables remain unchanged'},indent=2))
finally:
    if g:g.close();g.cleanup()
