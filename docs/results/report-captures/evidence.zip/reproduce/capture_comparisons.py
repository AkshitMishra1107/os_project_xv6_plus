from pathlib import Path
import os,sys,subprocess,tempfile,tarfile,io,json
ROOT=Path(__file__).resolve().parents[2];REPO=ROOT/'xv6-plus'
OUT=ROOT/'report-evidence/report-comparison-refresh'
assert not OUT.exists()
os.environ['XV6_RESULTS']=str(OUT);sys.path.insert(0,str(REPO/'tools'))
from validation.harness import Guest
original_popen=subprocess.Popen
def readable(args,*a,**k):
    if isinstance(args,list):args=[x.replace('vc,id=vc0,cols=90,rows=30','vc,id=vc0,cols=64,rows=46') for x in args]
    return original_popen(args,*a,**k)
subprocess.Popen=readable
g=None
try:
    with tempfile.TemporaryDirectory(prefix='xv6-baseline-capture-') as temp:
        data=subprocess.check_output(['git','archive','v0.0'],cwd=REPO)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:archive.extractall(temp,filter='data')
        g=Guest('historical-eager-v0.0',source=Path(temp),cpus=1,ram=128,policy=1)
        g.cmd('baseline','sbrk(200MB) failed');assert g.capture('reservation-failure')
        g.close();g.cleanup();g=None
    g=Guest('cow-writeall',source=REPO,cpus=1,ram=128,policy=1)
    g.cmd('forkbench writeall 10','forkbench: OK');assert g.capture('writeall')
    g.close();g.cleanup();g=None
    g=Guest('pressure-and-ownership',source=REPO,cpus=1,ram=8,policy=1)
    for cmd,marker,label in [('memhog 12','child exit status 0','full-page-pressure'),
                              ('swapfork','swapfork: OK','fork'),
                              ('threadswap','threadswap: OK','shared-paging'),
                              ('swapcheck','swapcheck: OK','owners'),
                              ('finaldemo 4','full-page bad=0','combined'),
                              ('swapcheck','swapcheck: OK','combined-audit')]:
        g.cmd(cmd,marker);assert g.capture(label)
    g.close();g.cleanup();g=None
    g=Guest('clock-hot',source=REPO,cpus=1,ram=8,policy=2)
    g.cmd('pagebench hot 6000 1','pagebench: OK');assert g.capture('hot-pattern')
    g.close();g.cleanup();g=None
    (OUT/'complete.json').write_text(json.dumps({'complete':True,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        'historical_tag':subprocess.check_output(['git','rev-parse','v0.0'],cwd=REPO,text=True).strip(),
        'timing_use':'Illustrative recaptures only; controlled multi-trial tables remain unchanged',
        'viewport':{'columns':64,'rows':46}},indent=2))
finally:
    if g:g.close();g.cleanup()
