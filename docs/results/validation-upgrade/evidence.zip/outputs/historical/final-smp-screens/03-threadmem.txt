threadmem
threadmem: OK (concurrent lazy faults, shared growth, inherited COW visibility)
$ 