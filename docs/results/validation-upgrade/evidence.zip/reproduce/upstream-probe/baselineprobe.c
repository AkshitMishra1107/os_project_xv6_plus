#include "kernel/types.h"
#include "user/user.h"
int main(void) {
  char *eager = sbrk(200 * 1024 * 1024);
  printf("upstream: sbrk(200MiB) %s\n", eager == (char *)-1 ? "failed" : "succeeded");
  if(eager != (char *)-1) sbrk(-200 * 1024 * 1024);
  char *lazy = sbrklazy(200 * 1024 * 1024);
  printf("upstream: sbrklazy(200MiB) %s\n", lazy == (char *)-1 ? "failed" : "succeeded");
  exit(eager == (char *)-1 && lazy != (char *)-1 ? 0 : 1);
}
